# Lead-Scoring-Case-Study
This repository contains all the necessary files i.e code script, answers for specific question from the company, presentation for the case study and summary report.
